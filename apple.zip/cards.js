const bin = "543897"
const nomor = Math.floor(Math.random() * 2391839128) + 2893478237;
const vcc = "555"

var tahun = ['2025', '2026', '2027']; 
var rand = tahun[(Math.random() * tahun.length) | 0]

console.log(bin + nomor + "|" + rand + "|" + vcc)