const fetch = require('node-fetch');
const cheerio = require('cheerio');
const userInfo = 'audreymedhurst130';
const url = 'https://mailnesia.com/mailbox/' + userInfo; // MAILBOX

const getProduct = () => new Promise((resolve,reject) => {
    fetch(url, {
        method: 'GET',
        headers: {
            'user-agent': 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Mobile Safari/537.36'
        }
}) //pake promise


    .then (res => res.text())
    .then(result => {
        const $ = cheerio.load(result);
        const menu = $('#main > div.container > div > div > p > b').text();
        resolve("OTP Apple is : " + menu )
    })
    .catch(err => reject(err))

});
    
    (async () => {
        const detailPrice = await getProduct()
        console.log(detailPrice)
        
    })();