const fetch = require('node-fetch');
const cheerio = require('cheerio');
const url = 'https://mailnesia.com/mailbox/AliyahBoyle76';

const getProduct = () => new Promise((resolve,reject) => {
    fetch(url, {
        method: 'GET',
        headers: {
            'user-agent': 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Mobile Safari/537.36'
        }
}) 

    .then (res => res.text())
    .then(result => {
        const $ = cheerio.load(result);
        let anchorElem = $("a[class='email']");
        let link = anchorElem.attr("href");        
        resolve(link)
    })
    .catch(err => reject(err))

});
    
    (async () => {
        const detailPrice = await getProduct()
        console.log(detailPrice)
        const resUrl = 'https://mailnesia.com/' + detailPrice;
        console.log(resUrl)
    })();
